package value

/**
 * A Value trait.
 */
trait Value
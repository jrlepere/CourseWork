class CenTherm {
  // = degrees Centigrade 
  def computeTemp(city: String) = 1
  // Not sure how this is done, but I don't care. 
  // This class is 'given' and should have been implemented by some other programmer.
}
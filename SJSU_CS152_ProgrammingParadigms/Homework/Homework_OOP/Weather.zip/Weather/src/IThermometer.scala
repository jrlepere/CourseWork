
trait IThermometer {
   // = avg degrees Farenheit
   def getMeanTemperature(cities: List[String]): Double
}
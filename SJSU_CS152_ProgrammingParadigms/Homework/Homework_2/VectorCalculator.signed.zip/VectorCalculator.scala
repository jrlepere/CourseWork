object VectorCalculator {

  def add(v1: Array[Int], v2: Array[Int]) = {
    val maxLength = Math.max(v1.length, v2.length)
    val v = new Array[Int](maxLength)
    for (i <- 0 until maxLength) {
      if (i < v1.length && i < v2.length) v(i) = v1(i) + v2(i)
      else if (i < v1.length) v(i) = v1(i)
      else v(i) = v2(i)
    }
    v
  }

  def dot(v1: Array[Int], v2: Array[Int]) = {
    var dotProd = 0
    for (i <- 0 until Math.min(v1.length, v2.length)) dotProd += v1(i) * v2(i)
    dotProd
  }

  def toString(v: Array[Int]) = {
    var result = "["
    for (e <- v) {
      result = result + " " + e
    }
    result = result + "]"
    result
  }

  def main(args: Array[String]): Unit = {
    try {
      print("Enter 3 integers: ")
      var x = readInt()
      var y = readInt()
      var z = readInt()
      val vec1 = Array(x, y, z)
      val vec2 = Array(1, 2, 3)
      val vec3 = add(vec1, vec2)
      println("sum = " + toString(vec3))
      println("dot = " + dot(vec1, vec2))
    } catch {
      case e: Exception => { println(e) }
    }

  }

}

object TaxCalculator {
  
  def tax(income: Double): Double = {
     if (income < 0.0) throw new IllegalArgumentException("Income can't be negative")
     else if (income < 20000) income * 0.00
     else if (income < 30000) income * 0.05
     else if (income < 40000) income * 0.10
     else if (income < 60000) income * 0.23
     else if (income < 100000) income * 0.32
     else income * 0.50
   } 

}
import Array._

object MatrixCalculator {

  // converts matrix to a string
  def toString(matrix: Array[Array[Int]]) = {
    var s = "\n"
    for (i <- matrix.indices; j <- matrix.indices) {
      if (j == 0) s += "\n"
      s += matrix(i)(j) + " "
    }
    s + "\n"
  }

  // returns the sum of the diagonal entries of a matrix
  def trace(m: Array[Array[Int]]) = {
    var s = 0
    for (i <- m.indices) s += m(i)(i)
    s
  }

  // returns a dim x dim matrix with i/j entry = 3 * i + 2 * j % cap
  def makeArray(dim: Int, cap: Int = 100) = {
    val m = new Array[Array[Int]](dim)
    for (i <- m.indices) m(i) = new Array[Int](dim)
    for (i <- m.indices; j <- m.indices) m(i)(j) = 3 * i + 2 * j % cap 
    m
  }

  def main(args: Array[String]): Unit = {
    print("Enter a positive integer: ")
    var n = readInt
    var m = makeArray(n)
    println(toString(m))
    println("trace = " + trace(m))
  }

}

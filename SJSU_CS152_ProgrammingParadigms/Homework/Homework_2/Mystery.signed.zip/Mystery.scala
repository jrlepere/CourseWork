import util.control.Breaks._

object Mystery {

  /*
   * public class Mystery {
   * 	public static void main(String args[]) {
   * 		for(int i = 0; i < 10; i++) {
   * 			for(int j = 0; j < 10; j++) {
   * 				if ((i + j) % 10 == 3) continue;
   * 				if (i + j == 15) break;
   * 				System.out.println("i = " + i + ", j = " + j);
   * 			}
   * 		}
   * 	}
   * }
   */
  def main(args: Array[String]): Unit = {

    for (i <- 0 until 10)
      breakable {
        for (j <- 0 until 10) {
          if ((i + j) % 10 != 3) {
            if (i + j == 15) break
            println("i = " + i + ", j = " + j)
          }
        }
      }

  }

}
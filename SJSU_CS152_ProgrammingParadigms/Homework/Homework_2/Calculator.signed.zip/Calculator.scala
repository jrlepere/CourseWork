object Calculator {

  // = 1 * 2 * 3 * ... * n
  def fact(n: Integer) = {
    var r = 1
    for (i <- 1 to n) {
      r *= i
    }
    r
  }

  // = 1 + 2 + 3 + ... + n
  def tri(n: Integer) = {
    var r = 0
    for (i <- 1 to n) {
      r += i
    }
    r
  }

  // = 2^n
  def exp(n: Integer) = {
    if (n == 0) 1
    else {
      var r = 2
      for (i <- 2 to n) {
        r *= 2
      }
      r
    }
  }

  // = true if n >= 2 and has no smaller divisors
  def isPrime(n: Integer) = {
    if (n >= 2) {
      var r = true
      for (i <- 2 to n - 1) {
        if (n % i == 0) {
          r = false
        }
      }
      r
    } else false
  }

  def main(args: Array[String]): Unit = {
    println("enter 3 integers x, y, and z on separate lines: ")
    var x = readInt()
    var y = readInt()
    var z = readInt()
    println("fact(x) = " + fact(x))
    println("fact(y) = " + fact(y))
    println("fact(z) = " + fact(z))
    println("tri(x) = " + tri(x))
    println("tri(y) = " + tri(y))
    println("tri(z) = " + tri(z))
    println("exp(x) = " + exp(x))
    println("exp(y) = " + exp(y))
    println("exp(z) = " + exp(z))
    println("isPrime(x) = " + isPrime(x))
    println("isPrime(y) = " + isPrime(y))
    println("isPrime(z) = " + isPrime(z))
  }

}

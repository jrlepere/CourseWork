/**
 * This list represents a bag containing multiple objects and the amount per object
 */
public class Bag
{
   Node first;

   /**
    * A Node with data and a count
    */
   class Node
   {
      Object data;
      int count;
      Node next;
   }

   /**
    * Constructs an empty bag
    */
   public Bag()
   {
      first = null;
   }

   /**
    * Adds an object to bag
    * @param obj the object
    */
   public void add(Object obj)
   {
	   Node newNode = new Node();
	   if (!hasFirst()) {
		   newNode.data = obj;
		   newNode.count = 1;
		   first = newNode;
	   } else {
		   Node firstHolder = first;
		   boolean found = false;
		   while (hasFirst() && !found) {
			   if (first.data.equals(obj)) {
				   first.count++;
				   first = firstHolder;
				   found = true;
			   } else {
				   if (hasNext()) {
					   first = first.next;
				   } else {
					   newNode.data = obj;
					   newNode.count = 1;
					   first = newNode;
					   first.next = firstHolder;
					   found = true;
				   }
			   }
		   }
	   }
   }

   /**
    * Removes an object from the bag
    * @param obj the object
    */
   public void remove(Object obj)
   {
      // ...
   }

   /**
    * Gets the amount of times the object is in the bag
    * @param obj the object
    * @return the count of the object
    */
   public int contains(Object obj)
   {
	   if (hasFirst()) {
		   Node firstHolder = first;
		   boolean end = false;
		   while (hasFirst() && !end) {
			   if (first.data.equals(obj)) {
				   int count = first.count;
				   first = firstHolder;
				   return count;
			   } else {
				   if (hasNext()) {
					   first = first.next;
				   } else {
					   end = true;
				   }
			   }
		   }
		   first = firstHolder;
		   return 0;
	   } else {
		   return 0;
	   }
   }
   
   /**
    * Checks if there is a first node
    * @return if there is a first node
    */
   private boolean hasFirst()
   {
	   return first != null;
   }
   
   /**
    * Checks if there is a next node
    * @return if there is a next node
    */
   private boolean hasNext()
   {
	   return first.next != null;
   }

   /**
    * Returns the bag as a string
    * @return the bag as a string
    */
   public String toString()
   {
      String result = "[";
      // ...
      return result + "]";
   }
}

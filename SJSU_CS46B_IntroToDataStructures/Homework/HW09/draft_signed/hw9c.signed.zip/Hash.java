import java.util.Scanner;

/**
 * This program is a solution to Exercise P15.4 in the textbook
 * @author JLepere2
 */
public class Hash 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		while (in.hasNext()) {
			String word = in.next();
			System.out.println(word.hashCode() + ": " + word);
		}
		in.close();
	}
}

import java.util.Scanner;
import java.util.Stack;

/**
 * This program is a solution to problem E15.6 in the textbook
 * @author JLepere2
 */
public class Reverse 
{
	public static void main(String[] args) 
	{
		Stack<String> stack = new Stack<String>();
		Scanner in = new Scanner(System.in);
		String line = in.nextLine();
		Scanner lineScanner = new Scanner(line);
		boolean first = true;
		while (lineScanner.hasNext()) {
			String word = lineScanner.next();
			if (!word.endsWith(".")) {
				if (first) {
					stack.push(word.substring(0, 1).toLowerCase() + word.substring(1) + ".");
					first = false;
				} else {
					stack.push(word);
				}
			} else {
				stack.push(word.substring(0, 1).toUpperCase() + word.substring(1, word.length()-1));
				while (stack.size() > 0) {
					System.out.print(stack.pop() + " ");;
				}
				first = true;
			}
		}
		lineScanner.close();
		in.close();
	}
}
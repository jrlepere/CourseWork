import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Lists 
{
	/**
	 * Calculates the permutations of a string
	 * @param s the string
	 * @return an array of the permutations of a string
	 */
	public static ArrayList<String> permutations(String s)
	{
		// Assuming s is of length 2
		ArrayList<String> result = new ArrayList<>();	
		Queue<String> q = new LinkedList<>();
		
		// When working with the split method, using the regex "|" would 
		//not work so I used "/"
		if (s.isEmpty()) {
			result.add("");
			return result;
		}
		q.add("/"+s); // adds / + s to the queue
		while (!q.isEmpty()) {
			String str = q.poll();
			String[] array = str.split("/");
			String first = "";
			String second = "";
			if (!str.endsWith("/")) {
				first = array[0];
				second = array[1];
			} else {
				first = array[0];
			}
			if (!second.isEmpty()) {
				for (int i = 0; i < second.length(); i ++) {
					String toAdd = first + second.charAt(i) + "/";
					if (i != second.length()-1) {
						toAdd += second.substring(0,i) + second.substring(i+1);
					} else {
						toAdd += second.substring(0,i);
					}
					q.add(toAdd);
				}
			} else {
				result.add(first);
			}
		}
		
		return result;
	}
}
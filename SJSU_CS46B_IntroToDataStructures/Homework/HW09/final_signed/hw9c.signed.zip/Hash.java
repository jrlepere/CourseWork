import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * This program is a solution to Exercise P15.4 in the textbook
 * @author JLepere2
 */
public class Hash 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		Map<Integer, TreeSet<String>> map = new TreeMap<>();
		
		while (in.hasNext()) {
			String str = in.next();
			int hash = str.hashCode();
			if (map.containsKey(hash)) {
				TreeSet<String> set = map.get(hash);
				set.add(str);
				map.put(hash, set);
			} else {
				TreeSet<String> set = new TreeSet<>();
				set.add(str);
				map.put(hash, set);
			}
		}
		in.close();
		
		for (Integer hashCode : map.keySet()) {
			if (map.get(hashCode).size()>1) {
				System.out.print(hashCode + ": ");
				boolean first = true;
				for (String s : map.get(hashCode)) {
					if (first) {
						System.out.print(s);
						first = false;
					} else {
						System.out.print(", " + s);
					}
				}
				System.out.print("\n");
			}
		}
	}
}

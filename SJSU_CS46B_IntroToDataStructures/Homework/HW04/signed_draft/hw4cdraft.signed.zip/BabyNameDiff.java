import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;

public class BabyNameDiff
{
   public static void main(String[] args) throws FileNotFoundException
   {
      String filename1 = args[0];
      String filename2 = args[1];
      
      ArrayList<String> names1 = read(filename1);
      ArrayList<String> names2 = read(filename2);
      
      
      ArrayList<String> namesInFirstButNotSecond = new ArrayList<>();
      for (int i = 0; i < names1.size(); i ++) {
    	  String name1ToCompare = names1.get(i);
    	  boolean foundSimilarName = false;
    	  for (int j = 0; j < names2.size() && !foundSimilarName; j ++) {
    		  String name2ToCompare = names2.get(j);
    		  if (name1ToCompare.equals(name2ToCompare)) {
    			  foundSimilarName = true;
    		  }
    	  }
    	  if (!foundSimilarName) {
    		  namesInFirstButNotSecond.add(name1ToCompare);
    	  }
      }
      Collections.sort(namesInFirstButNotSecond,
              new Comparator<String>()
              {
                  public int compare(String name1, String name2)
                  {
                      return name1.toString().compareTo(name2.toString());
                  }        
              });
      for (String name : namesInFirstButNotSecond) {
    	  System.out.println(name);
      }
   }

   private static ArrayList<String> read(String filename) throws FileNotFoundException
   {
	   ArrayList<String> names = new ArrayList<>();
       Scanner in = new Scanner(new File(filename));
       while (in.hasNextLine()) {
    	   String line = in.nextLine();
    	   Scanner lineScanner = new Scanner(line);
    	   boolean nameFound = false;
    	   while (lineScanner.hasNext() && !nameFound) {
    		   int value = lineScanner.nextInt();
    		   String name = lineScanner.next();
    		   nameFound = true;
    		   names.add(name);
    	   }
    	   lineScanner.close();
       }
       in.close();
       return names;
   }
}
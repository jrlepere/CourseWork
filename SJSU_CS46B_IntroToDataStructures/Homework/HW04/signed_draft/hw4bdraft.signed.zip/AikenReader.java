import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class AikenReader 
{
	private File file;
	/**
	 * Creates a AikenReader 
	 * @param fileName
	 */
	public AikenReader(String fileName)
	{
		file = new File(fileName);
	}
	
	/**
	 * Reads the questions in the file
	 * return an ArrayList of Questions 
	 * @throws FileNotFoundException 
	 */
	public ArrayList<ChoiceQuestion> readQuestions() throws FileNotFoundException
	{
		ArrayList<ChoiceQuestion> questions = new ArrayList<>();
		Scanner in = new Scanner(file);
		while(in.hasNextLine()) {
			ChoiceQuestion cq = new ChoiceQuestion();
			String text = in.nextLine();
			cq.setText(text);
			ArrayList<String> results = new ArrayList<>();
			boolean found = false;
			while (in.hasNextLine() && !found)
			{
				String choice = in.nextLine();
				if (choice.trim().isEmpty()) {
					found = true;
				} else {
					results.add(choice);
				}
			}
			String answer = results.get(results.size()-1).substring(0, 1);
			for (int i = 0; i < results.size()-1; i ++) {
				String result = results.get(i);
				if (result.startsWith(answer)) {
					cq.addChoice(result.substring(2), true);
				} else {
					cq.addChoice(result.substring(2), false);
				}
			}
			questions.add(cq);
		}
		in.close();
		return questions;
	}
}
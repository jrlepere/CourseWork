import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Salaries
{
   public static void main(String[] args) throws FileNotFoundException
   {
      String filename = args[0];
      File salariesFile = new File(filename);
      Scanner in = new Scanner(salariesFile);
      while (in.hasNextLine()) {
    	  String line = in.nextLine();
    	  Scanner lineScanner = new Scanner(line);
    	  int amount = 0;
    	  boolean foundAmount = false;
    	  while (lineScanner.hasNext() && !foundAmount) {
    		  String word = lineScanner.next();
    		  if (word.startsWith("$")) {
    			  String value = "";
    			  for (int i = 0; i < word.length(); i ++) {
    				  if (Character.isDigit(word.charAt(i))) {
    					  value += word.charAt(i);
    				  }
    			  }
    			  amount += Integer.parseInt(value);
    		  }
    	  }
    	  lineScanner.close();
    	  if (amount != 0) {
    		  String amountString = "$" + amount;
    		  amountString = amountString.substring(0, 4) + "," + amountString.substring(4);
    		  System.out.println(amountString);
    	  }
      }
      in.close();
   }
}
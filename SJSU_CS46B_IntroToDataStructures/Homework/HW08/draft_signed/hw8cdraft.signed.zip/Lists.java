import java.util.*;

public class Lists
{
   /**
      Splices the given string before each list element.
      @param a a string
      @param b a list
      @return a list that contains a before each element of b
   */
   public static LinkedList<String> splice(String a, LinkedList<String> b)
   {
	   ListIterator<String> iter = b.listIterator();
	   LinkedList<String> c = new LinkedList<>();
	   while (iter.hasNext())
	   {
	      c.add(a);
	      String nextElement = iter.next();
	      c.add(nextElement);
	   }
	   return c;
   }
}
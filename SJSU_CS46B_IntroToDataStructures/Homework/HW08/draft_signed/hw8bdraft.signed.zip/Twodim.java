public class Twodim
{
   /**
      @param a a two-dimensional array
      @param r the starting row
      @param c the starting column
      @return the position of the minimum element in a startign at (r, c)
      as an array [row, column] of length 2 
   */
   public static int[] minimumPosition(int[][] a, int r, int c)
   {
      int[] minPos = new int[2];
      minPos[0] = r;
      minPos[1] = c;
      int smallestValue = a[r][c];
      for (int i = r; i < a.length; i ++) {
    	  for (int j = c; j < a[0].length; j ++) {
    		  if (a[i][j] < smallestValue) {
    			  smallestValue = a[i][j];
    			  minPos[0] = i;
    			  minPos[1] = j;
    		  }
    	  }
      }
      return minPos;
   }
}
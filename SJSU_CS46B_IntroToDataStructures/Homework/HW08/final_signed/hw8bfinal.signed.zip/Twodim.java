public class Twodim
{
	public static void sort(int[][] a)
	{
		// First loop is rows
		for (int i = 0; i < a.length; i ++) {
			// This loop is columns
			for (int j = 0; j < a[0].length; j ++) {
				int[] minPos = minimumPosition(a,i,j); // Gets the minimum value after the current position
				swap(a,i,j,minPos[0],minPos[1]); // swaps the current position with the smallest value
			}
		}
	}
	
   /**
      @param a a two-dimensional array
      @param r the starting row
      @param c the starting column
      @return the position of the minimum element in a startign at (r, c)
      as an array [row, column] of length 2 
   */
   public static int[] minimumPosition(int[][] a, int r, int c)
   {
      int[] minPos = new int[2];
      minPos[0] = r;
      minPos[1] = c;
      int smallestValue = a[r][c];
      for (int i = r; i < a.length; i ++) {
    	  for (int j = c; j < a[0].length; j ++) {
    		  if (a[i][j] < smallestValue) {
    			  smallestValue = a[i][j];
    			  minPos[0] = i;
    			  minPos[1] = j;
    		  }
    	  }
    	  c = 0;
      }
      return minPos;
   }
   
   public static void swap(int[][] a, int r1, int c1, int r2, int c2)
   {
	   int holder = a[r1][c1];
	   a[r1][c1] = a[r2][c2];
	   a[r2][c2] = holder;
   }
}
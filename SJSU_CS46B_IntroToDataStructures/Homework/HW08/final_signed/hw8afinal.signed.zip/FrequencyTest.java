import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class FrequencyTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test1() {
		int[] values = {3,5,6,5,6,3,5,2};
		int[] freq = Frequency.frequencyOfElements(values);
		int[] expected = {2,3,2,3,2,2,3,1};
		assertArrayEquals(expected, freq);
	}
	
	@Test
	public void test2() {
		int[] values = {2,2,2,2,2};
		int[] expected = {5,5,5,5,5};
		assertArrayEquals(expected, Frequency.frequencyOfElements(values));
	}
	
	@Test
	public void test3() {
		int[] values = {1,2,3,4,5,6,7,8,9};
		int[] expected = {1,1,1,1,1,1,1,1,1};
		assertArrayEquals(expected, Frequency.frequencyOfElements(values));
	}
	
	@Test
	public void test4() {
		int[] values = {100,100,50,100,8};
		int[] expected = {3,3,1,3,1};
		assertArrayEquals(expected, Frequency.frequencyOfElements(values));
	}
}

import java.util.Arrays;

public class Frequency
{
	private static class Element implements Comparable<Element>
	   {
	      public int value;
	      public int position;

	      public Element(int value, int position)
	      {
	         this.value = value;
	         this.position = position;
	      }

	      public int compareTo(Element other) 
	      {
	         return Integer.compare(value, other.value);
	      }
	   }

   /**
      Returns an array of the frequencies of each element in a.
      That is, if the returned array is f, then a[i] occurs f[i]
      times in a.
      @return the frequency array
   */
   public static int[] frequencyOfElements(int[] a)
   {
	   // a = [3,5,6,5,6,3,5,2]
	   // elements = [(3,0),(5,1),(6,2),(5,3),(6,4),(3,5),(5,6),(2,7)]
	   // elements = [(2,7),(3,0),(3,5),(5,1),(5,3),(5,6),(6,2),(6,4)]
	   // frequencies = [2,3,2,3,2,2,3,1]
	   
	   Element[] elements = new Element[a.length]; //Creates an array of elements of length a
	   // Initializes elements
	   for (int i = 0; i < a.length; i ++) {
		   elements[i] = new Element(a[i],i);
	   }
	   
	   Arrays.sort(elements); // Sorts elements
	   
	   int[] frequencies = new int[a.length];
	   for (int i = 0; i < elements.length; i ++) {
		   int value = elements[i].value;
		   int count = 1;
		   boolean found = false;
		   while (!found) {
			   if (i < a.length-1) {
				   i ++;
				   if (value == elements[i].value) {
					   count ++;
				   } else {
					   found = true;
					   i --;
				   }
			   } else {
				   found = true;
			   }
		   }
		   for (int k = (i+1) - count; k < i+1; k ++) {
			   frequencies[elements[k].position] = count;
		   }
	   }
	   return frequencies;
   }
}


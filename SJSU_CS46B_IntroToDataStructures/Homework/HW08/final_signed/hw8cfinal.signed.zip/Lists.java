import java.util.*;

public class Lists
{
   /**
      Splices the given string before each list element.
      @param a a string
      @param b a list
      @return a list that contains a before each element of b
   */
   public static LinkedList<String> splice(String a, LinkedList<String> b)
   {
	   ListIterator<String> iter = b.listIterator();
	   LinkedList<String> c = new LinkedList<>();
	   while (iter.hasNext())
	   {
	      c.add(a);
	      String nextElement = iter.next();
	      c.add(nextElement);
	   }
	   return c;
   }

   /**
      Splices the given lists.
      @param a a list
      @param b a list
      @return a list that contains alternating elements of a and b, 
      and if one list is longer than the other, the tail of the 
      longer list
   */
   public static LinkedList<String> splice(LinkedList<String> a, LinkedList<String> b)
   {
      LinkedList<String> c = new LinkedList<>();
      
      // Creates ListIterators for a and b
      ListIterator<String> iterA = a.listIterator();
      ListIterator<String> iterB = b.listIterator();
      
      // Loops through the Lists until one is has executed
      while(iterA.hasNext() && iterB.hasNext()) {
    	  String elementA = iterA.next();
    	  String elementB = iterB.next();
    	  c.addLast(elementA);
    	  c.addLast(elementB);
      }
      
      // Atleast one of the following loops will not execute
      // Adds the rest of the List to c
      while(iterA.hasNext()) {
    	  String elementA = iterA.next();
    	  c.addLast(elementA);
      }
      while(iterB.hasNext()) {
    	  String elementB = iterB.next();
    	  c.addLast(elementB);
      }
      
      return c;
   }

   /**
      Removes all elements from b that end in the string a
      @param a a string
      @param b a list
   */
   public static void removeEndingWith(String a, LinkedList<String> b)
   {
	   ListIterator<String> iter = b.listIterator();
	   while (iter.hasNext()) {
		   String element = iter.next();
		   if (element.endsWith(a)) {
			   iter.remove();
		   }
	   }
   }
}
public class Demolition
{
   public static int cost(String s)
   {
	   String str = s;
	   if (str.length() == 1) {return 0;}
	   int cost = 0;
	   String first = str.substring(0, 1);
	   String last = str.substring(str.length()-1);
	   int c1 = stepCost(first,str.substring(1));
	   int c2 = stepCost(last,str.substring(0, str.length()-1));
	   if (c1 < c2) {
		   str = str.substring(1);
		   cost = c1 + cost(str);
	   } else if (c1 > c2) {
		   str = str.substring(0, str.length()-1);
		   cost = c2 + cost(str);
	   } else {
		   String nextFirst = str.substring(1, 2);
		   String nextLast = str.substring(str.length()-2, str.length()-1);
		   int c11 = stepCost(nextFirst,str.substring(2));
		   int c21 = stepCost(nextLast,str.substring(0, str.length()-2));
		   if (c11 <= c21) {
			   str = str.substring(1);
			   cost = c1 + cost(str);
		   } else {
			   str = str.substring(0, str.length()-1);
			   cost = c2 + cost(str);
		   }
	   }
	   return cost;
   }

   public static int stepCost(String letter, String rest) 
   {
      return "aeiou".contains(letter) ? 0 : rest.length();
   }
}
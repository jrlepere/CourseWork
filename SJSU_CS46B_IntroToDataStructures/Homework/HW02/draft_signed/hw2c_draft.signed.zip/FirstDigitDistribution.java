
public class FirstDigitDistribution
{
	int[] counters;
	
	public FirstDigitDistribution() 
	{
		counters = new int[10];
	}
	
	public void process(Sequence seq, int valuesToProcess) 
	{
		for (int i = 1; i <= valuesToProcess; i++) {
			int value = seq.next();
			value = Math.abs(value);
			boolean found = false;
			while(!found) {
				if(value < 10) {
					found = true;
					int firstDigit = value;
					counters[firstDigit]++;
				} else { 
					value /= 10;
				}
			}
		}
	}	
	
	public void display()
	{
		for(int i = 0; i < counters.length; i ++) {
			System.out.println("" + (i) + ": " + counters[i]);
		}
	}
}

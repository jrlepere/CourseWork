RUNNING THE PROGRAM
1) cd to src dir
2) javac *.java
3) java Main

PRORGAM OUTPUT
The program prints an information page at the beginning of execution. To meet the requirements, 3 solutions are found and printed using RRHC and GEN when respective algorithm is selected. I do not recommend entering A for Analysis. This was used for gathering data. I switched the max executions to 100, which is not too bad, because I used 1000 for my report. Enter Q to break the loop.
See CommandLineExample.png if needed.

REPORT/ANALYSIS
The report is included in the current directory along with an excel spread sheet containing the data collected and consolidated.
